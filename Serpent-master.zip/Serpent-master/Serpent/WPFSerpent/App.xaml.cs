﻿using System.Windows;

namespace WpfSerpent
{
    /// <summary>
    /// Logika interakcji dla klasy App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
